<?php $__env->startSection('content'); ?>
<div class="container">
    <?php if(session('status')): ?>
    <div class="alert alert-success" role="alert">
        <?php echo e(session('status')); ?>

    </div>
    <?php endif; ?>

<h1>Listado de Formularios</h1>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.encuestador', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\LaravelEmail\project\resources\views/encuestador/listarEncuestas.blade.php ENDPATH**/ ?>