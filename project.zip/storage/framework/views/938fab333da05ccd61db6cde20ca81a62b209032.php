<?php echo $__env->make("../layouts/userInformation", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->startSection('nav'); ?>
    <?php echo $__env->make("../layouts/navadmin", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <?php if(session('status')): ?>
    <div class="alert alert-success" role="alert">
        <?php echo e(session('status')); ?>

    </div>
<?php endif; ?>

<h1>List admins</h1>
<?php if(session('mensaje')): ?>
<div class="alert alert-success">
  <?php echo e(session('mensaje')); ?>

</div>
<?php endif; ?>

<div id="alert" class="alert alert-info"></div>

<table class="table">
  <thead>
    <tr>
      <th scope="col">#</th>
      <th scope="col">Documento</th>
      <th scope="col">Nombre</th>
      <th scope="col">Apellido</th>
      <th scope="col">Correo</th>
      <th scope="colgroup">Opciones</th>
    </tr>
  </thead>
  <tbody>
    <?php $__currentLoopData = $admins; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $admin): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

    <tr>
        <th scope="row"><?php echo e($admin->id); ?></th>
        <td  class="clickable-row" data-href="<?php echo e(route('admin.show',$admin->id)); ?>"><?php echo e($admin->personal_id); ?></td>
        <!--<td><a href="<?php echo e(route('admin.show',$admin->id)); ?>"><?php echo e($admin->name); ?></a></td>-->
        <td  class="clickable-row" data-href="<?php echo e(route('admin.show',$admin->id)); ?>"><?php echo e($admin->name); ?></td>
        <td  class="clickable-row" data-href="<?php echo e(route('admin.show',$admin->id)); ?>"><?php echo e($admin->lastname); ?></td>
        <td  class="clickable-row" data-href="<?php echo e(route('admin.show',$admin->id)); ?>"><?php echo e($admin->email); ?></td>
        <td><a href="<?php echo e(route('admin.edit', $admin->id)); ?>" class="btn btn-warning btn-sm">Editar</a>
          <form action="<?php echo e(route('admin.destroy',$admin->id)); ?>" class="d-inline" method="POST">
            <?php echo method_field('DELETE'); ?>
            <?php echo csrf_field(); ?>
            <button class="btnDelete btn btn-danger btn-sm ">Eliminar</button>
          </form>
        </td>

      </tr>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

  </tbody>
</table>
<?php echo e($admins->links()); ?>


</div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('script_section'); ?>
<script src="<?php echo e(URL::asset('js/myscript.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\LaravelEmail\project\resources\views/admin/list.blade.php ENDPATH**/ ?>