<?php echo $__env->make("../layouts/userInformation", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->startSection('nav'); ?>
    <?php echo $__env->make("../layouts/navevaluator", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
    <h1>Ey Juano, Here is where you have to build your html to show the surveys</h1>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\LaravelEmail\project\resources\views/evaluator/listSurvey.blade.php ENDPATH**/ ?>