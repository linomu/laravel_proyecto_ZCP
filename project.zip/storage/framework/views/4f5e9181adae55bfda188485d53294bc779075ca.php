<?php $__env->startSection('nav'); ?>
    <?php echo $__env->make("../layouts/navadmin", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <?php if(session('status')): ?>
    <div class="alert alert-success" role="alert">
        <?php echo e(session('status')); ?>

    </div>
<?php endif; ?>

<h1>Actualizar un Administrador</h1>
<?php if(session('mensaje')): ?>
    <div class="alert alert-success">
      <?php echo e(session('mensaje')); ?>

    </div>
<?php endif; ?>
<div class="col-sm-6">
  <form action="<?php echo e(route('admin.update',$admin->id)); ?>" method="POST" class="p-5 bg-white">
    <?php echo method_field('PUT'); ?>
    <?php echo csrf_field(); ?>
      <div class="row form-group">
        <?php $__errorArgs = ['txt_personal_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <div class="alert alert-danger">El Documento es obligatorio <?php echo e($message); ?>

          <button type="button" class="close" data-dismiss="alert" aria-label="Close">
              <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        <div class="col-md-12 mb-3 mb-md-0">
          <label class="font-weight-bold" for="fullname">Cédula</label>
        <input type="text" name="txt_personal_id" class="form-control" placeholder="Cédula" value="<?php echo e($admin->personal_id); ?>">
        </div>
      </div>
      <div class="row form-group">
        <?php $__errorArgs = ['txt_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <div class="alert alert-danger">El Nombre es obligatorio
          <button type="button" class="close" data-dismiss="alert" aria-label="Close">
              <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          <div class="col-md-12 mb-3 mb-md-0">
            <label class="font-weight-bold" for="fullname">Primer Nombre</label>
          <input type="text" name="txt_name" class="form-control" placeholder="Primer Nombre" value="<?php echo e($admin->name); ?>">
          </div>
        </div>
        <div class="row form-group">
          <?php $__errorArgs = ['txt_last_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
          <div class="alert alert-danger">El Apellido es obligatorio
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
          </div>
          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          <div class="col-md-12 mb-3 mb-md-0">
            <label class="font-weight-bold" for="fullname">Segundo Nombre</label>
          <input type="text" name="txt_last_name" class="form-control" placeholder="Segundo Nombre" value="<?php echo e($admin->lastname); ?>">
          </div>
        </div>
        <div class="row form-group">
          <?php $__errorArgs = ['txt_email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="alert alert-danger">El Correo Electronico es obligatorio
              <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                  <span aria-hidden="true">&times;</span>
              </button>
            </div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          <div class="col-md-12">
            <label class="font-weight-bold" for="email">Email</label>
          <input type="email" name="txt_email" class="form-control" placeholder="Email Address" value="<?php echo e($admin->email); ?>">
          </div>
        </div>

        <div class="row form-group">
          <div class="col-md-12">
            <input type="submit" value="Modificar" class="btn btn-primary rounded-0 btn-lg">
          </div>
        </div>
      </form>
  </div>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\LaravelEmail\project\resources\views/admin/edit.blade.php ENDPATH**/ ?>