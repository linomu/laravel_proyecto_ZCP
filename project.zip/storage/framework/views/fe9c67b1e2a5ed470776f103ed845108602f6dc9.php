<!DOCTYPE html>
<html lang="es-Es">
<head>
    <meta charset="utf-8">
</head>
<body>
    <h2>Bievenido a nuestro sitio Web</h2>
    <div>
        Tiene que seguir este link chiquillo! <?php echo e($name); ?>

    </div>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\LaravelEmail\project\resources\views/evaluator/surveyEmail.blade.php ENDPATH**/ ?>