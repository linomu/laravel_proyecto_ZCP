<?php $__env->startSection('firstImage'); ?>
    <img src="<?php echo e(URL::asset('images/img.jpg')); ?>" alt="..." class="img-circle profile_img">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('userName'); ?>
    <h2>John Doe</h2>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('imageName'); ?>
    <img src="<?php echo e(URL::asset('images/img.jpg')); ?>" alt="">Lino
<?php $__env->stopSection(); ?>
<?php /**PATH C:\xampp\htdocs\LaravelEmail\project\resources\views////layouts/userInformation.blade.php ENDPATH**/ ?>