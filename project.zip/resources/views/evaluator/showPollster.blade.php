@extends('layouts.master')

@include("../layouts/userInformation")


@section('nav')
    @include("../layouts/navevaluator")
@endsection


@section('content')
    <h1>Ey Pu, Here is where you have to show all the information about the Pollster</h1>
@endsection
