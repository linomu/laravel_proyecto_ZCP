@extends('layouts.master')
@include("../layouts/userInformation")

@section('nav')
    @include("../layouts/navevaluator")
@endsection


@section('content')
    <h1>Ey Pu, Here is where you have to show a form which one you can edit  Pollster</h1>
@endsection
