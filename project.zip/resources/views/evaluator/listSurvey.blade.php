@extends('layouts.master')

@include("../layouts/userInformation")

@section('nav')
    @include("../layouts/navevaluator")
@endsection


@section('content')
    <h1>Ey Juano, Here is where you have to build your html to show the surveys</h1>
@endsection
