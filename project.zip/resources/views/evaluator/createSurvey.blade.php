@extends('layouts.master')

@include("../layouts/userInformation")

@section('nav')
    @include("../layouts/navevaluator")
    @endsection


@section('content')
    <h1>Ey Juano, Here is where you have to build your form</h1>
    @endsection
