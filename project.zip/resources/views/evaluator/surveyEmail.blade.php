<!DOCTYPE html>
<html lang="es-Es">
<head>
    <meta charset="utf-8">
</head>
<body>
    <h2>Bievenido a nuestro sitio Web</h2>
    <div>
        Tiene que seguir este link chiquillo! {{ $name }}
    </div>
</body>
</html>
