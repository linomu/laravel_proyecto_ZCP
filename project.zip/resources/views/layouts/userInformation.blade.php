@section('firstImage')
    <img src="{{ URL::asset('images/img.jpg')}}" alt="..." class="img-circle profile_img">
@endsection
@section('userName')
    <h2>John Doe</h2>
@endsection
@section('imageName')
    <img src="{{ URL::asset('images/img.jpg') }}" alt="">Lino
@endsection
